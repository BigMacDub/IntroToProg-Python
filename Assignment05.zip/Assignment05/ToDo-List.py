'''
Title: To Do List Script
Dev: MWilson
Date: Apr 29, 2019
ChangeLog: (Who, When, What)
    MWilson, 4/29/2019, Original Release
'''

#Step 1: .txt file has been previously created
#Step 2: Assign data to a Python dictionary
#Step 3: Create Python list object
lstTable = []
with open("ToDoList.txt") as objF:
    for line in objF:
        lstTable.append({"Task:":line})
        if 'str' in line:
            break

#Step 4: Display contents of list to the user
print("Current List of Items:\n")
c = 0
while c < len(lstTable):
    print("Task ", c + 1, ": ", lstTable[c])
    c = c + 1

#Step 5: Allow the user to add or remove tasks from the list using numbered choices
while(True):
    def CurrentList():
        c = 0
        while c < len(lstTable):
            print("Task ", c + 1, ": ", lstTable[c])
            c = c + 1
    print("\nMenu of Options\n", "1) Show current data.\n", "2) Add a new item.\n",
          "3) Remove an existing item.\n", "4) Save Data to File.\n", "5) Exit Program.\n\n")
    optUser = input("Which option would you like to perform? [1 to 4] - ")

    if(optUser == "1"):
        print("Current List of Items:\n")
        print (CurrentList())

    elif(optUser == "2"):
        iTask = input("What is the task? ")
        iPri = input("What is the priority? (High/Low) ")
        dictRowNew = {"Task:": (iTask, iPri)}
        lstTable.append(str(dictRowNew))
        print(CurrentList())

    elif(optUser == "3"):
        iDel = input("Which task line would you like to delete? ")
        del lstTable[(int(iDel) - 1)]
        print("Current List of Items:\n")
        print(CurrentList())

    elif(optUser == "4"):
        objF = open("ToDoList.txt", 'w')
        objF.write(str(lstTable))
        objF.close()
        print("The following data was saved to a file:\n\r", lstTable)

# Step 6: Save the data from the table into the Todo.txt file when the program exits.
    else:
        objF = open("ToDoList.txt", 'w')
        objF.write(str(lstTable))
        objF.close()
        break