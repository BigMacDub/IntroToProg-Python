#-------------------------------------------------#
# Title: Eggseption
# Dev:   MWilson
# Date:  May 13, 2019
# ChangeLog: (Who, When, What)
#   MWilson, 05/13/2019, Created Script
#-------------------------------------------------#

#TXT file has been made named 'Egg.txt', program will search for a TXT file with a different name.

try:
    f = open("Eggs.txt")

except FileNotFoundError as e: #Exception for if the program could not find the specified file
    print("No eggs were found! Also, there was an error: ", e)

except Exception as e: #General exception for all other errors encountered
    print("Error!\n")
    print(e)

else: #Reads the file if found
    print(f.read())
    f.close()

finally: #End statement printed every time
    print("We're done here.")