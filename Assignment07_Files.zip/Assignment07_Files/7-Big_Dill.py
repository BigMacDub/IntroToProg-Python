#-------------------------------------------------#
# Title: Big Dill
# Dev:   MWilson
# Date:  May 13, 2019
# ChangeLog: (Who, When, What)
#   MWilson, 05/13/2019, Created Script
#-------------------------------------------------#

import pickle

#--Data--#
#This is the dictionary of items I'd like to pickle
pickle_dict = {1:"carrots",2:"kimchi",3:"pickles",4:"eggs",5:"cabbage"}


#--Processing--#
#Process to write the dictionary as binary to a DAT file
pickle_out = open("Pickling.dat","wb")
pickle.dump(pickle_dict,pickle_out)
pickle_out.close()

#Process to read the DAT file as plain text
pickle_in = open("Pickling.dat","rb")
pickle_dict = pickle.load(pickle_in)


#--I/O--#
#Print out the data for the user to see
print("Here is the list of things I need to pickle:\n")
print(pickle_dict)